# Coding-Raja-Technologies-Internship
Here's my Coding Raja Technologies Internship task 2 i.e Music Player
